(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9f3dde3e._.css",
  "static/chunks/node_modules_e5d443e9._.js",
  "static/chunks/_cc658d7e._.js"
],
    source: "dynamic"
});
