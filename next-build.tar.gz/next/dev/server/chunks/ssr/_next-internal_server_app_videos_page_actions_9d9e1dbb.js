module.exports = [
"[project]/.next-internal/server/app/videos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_videos_page_actions_9d9e1dbb.js.map