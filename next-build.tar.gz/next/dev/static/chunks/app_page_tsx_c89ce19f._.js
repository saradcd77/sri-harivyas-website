(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_63a96b73._.js",
  "static/chunks/_ad23dacb._.js"
],
    source: "dynamic"
});
