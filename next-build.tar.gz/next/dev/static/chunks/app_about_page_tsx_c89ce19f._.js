(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_541f9611._.js",
  "static/chunks/app_about_page_tsx_d589ce86._.js"
],
    source: "dynamic"
});
